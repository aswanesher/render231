<?php
 header("Access-Control-Allow-Origin: *");
 $con = mysqli_connect('mysql.idhostinger.com','u578939966_alfia','08051992','u578939966_alfia') or die ("could not connect database");
?>